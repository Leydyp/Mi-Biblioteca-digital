$('#guardar').on('click', function(){
	
	var contenido = $('#entrada').val();
	$('#entrada').val('');
	var parrafo_nuevo = $('<p></p>');
	parrafo_nuevo.text( contenido )
				 .on('click', function(){			
					 var respuesta = confirm("Estás seguro de eliminar tu nota?");
					 if(respuesta){
						 $(this).remove();
					 }
				 });
				 
	
	$('#notas').prepend( parrafo_nuevo );
	var cantidad = $('#notas p').length;
	parrafo_nuevo.css('background', '#d6d6d6');

	
});
$('#notasguardadas').on('pagebeforeshow', function(){
	$('#notas').next().next().css('background', '#d6d6d6');
});


