$('form').on('submit',function( ){
		var autor = $('#autor').val( );
        var editorial = $('#editorial').val( );
        var fecha = $('input[type=date]').val( );
		var idioma = $('#idioma').val( );
		var nombre = $('#nombre').val( );
		var estado = $('#estado').val( );
		var nuevo_div = $('<div></div>');
		var contenido = '<strong>' + nombre + '</strong><br>' +
		'Autor:  ' +autor+
        '<br> Editorial:  ' +editorial+    
        '<br>Fecha de lanzamiento: ' +fecha +  
		'<br>Idioma: ' + idioma +
		'<br>Estado: ' + estado 

		
		nuevo_div.html( contenido );
		var cant_divs = $('#grilla > div' ).length;
		
		$('#grilla').append( nuevo_div );
		
		if( cant_divs % 2 == 0 )
		{ 
			nuevo_div.attr( 'class', 'ui-block-a');
		}
		else
		{
			nuevo_div.attr( 'class',  'ui-block-b');
		}
		
		/*Creamos y agregamos un nuevo impuesto a la grilla, por ende, llamamos a la función para que guarde todos los impuestos con este nuevo incluido.*/
		guardarDatos();
		
		$.mobile.navigate('#libros');
		
		return false;
	}
);

